﻿using Problem1_Harvesting_Fields.Core;

namespace Problem1_Harvesting_Fields
{
    class Startup
    {
        private static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}