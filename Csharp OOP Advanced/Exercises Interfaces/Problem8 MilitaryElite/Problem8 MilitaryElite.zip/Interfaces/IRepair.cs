﻿namespace Problem8_MilitaryElite
{
    public interface IRepair
    {
        int HoursWorked { get; }
        string PartName { get; }
    }
}