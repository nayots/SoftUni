﻿namespace Problem8_MilitaryElite.Enums
{
    public enum MissionState
    {
        inProgress,
        Finished
    }
}